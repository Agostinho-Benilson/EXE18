package com.example.exe_18;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText number;
    private TextView result;
    private Button scan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number = findViewById(R.id.number);
        result = findViewById(R.id.result);
        scan = findViewById(R.id.scan);

        scan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int count = 0 ;
                    int n1 = Integer.parseInt(number.getText().toString());
                    for(int i = 1 ; i<=n1 ; i++){
                        if(n1 % i == 0)
                            count++;
                    }

                    if(count <= 2)
                        result.setText("É Primo");
                    else
                        result.setText("Não é Primo");
                }

        });



    }

    /*public void scan (View view ){
        int count = 0 ;
         int n1 = Integer.parseInt(number.getText().toString());
            for(int i = 1 ; i<=n1 ; i++){
                if(n1 % i == 0)
                    count++;
            }

                if(count <= 2)
                    result.setText("É Primo");
                else
                    result.setText("Não é Primo");
    }*/
}